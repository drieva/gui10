using System;
using System.Windows.Forms;

namespace CountVowelsModularized
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void countButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;
            int count = 0;
            foreach (char c in input)
            {
                if (IsVowel(c))
                {
                    count++;
                }
            }
            MessageBox.Show($"The number of vowels in the string is: {count}");
        }

        private bool IsVowel(char c)
        {
            c = char.ToLower(c);
            return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
        }
    }
}

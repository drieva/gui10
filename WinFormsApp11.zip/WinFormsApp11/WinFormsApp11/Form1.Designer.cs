﻿namespace CountVowelsModularized
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.inputLabel = new System.Windows.Forms.Label();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.countButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Location = new System.Drawing.Point(12, 19);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(89, 17);
            this.inputLabel.TabIndex = 0;
            this.inputLabel.Text = "Enter String:";
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(107, 16);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(219, 22);
            this.inputTextBox.TabIndex = 1;
            // 
            // countButton
            // 
            this.countButton.Location = new System.Drawing.Point(107, 54);
            this.countButton.Name = "countButton";
            this.countButton.Size = new System.Drawing.Size(75, 28);
            this.countButton.TabIndex = 2;
            this.countButton.Text = "Count";
            this.countButton.UseVisualStyleBackColor = true;
            this.countButton.Click += new System.EventHandler(this.countButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(338, 94);
            this.Controls.Add(this.countButton);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.inputLabel);
            this.Name = "Form1";
            this.Text = "Count Vowels";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label inputLabel;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Button countButton;
    }
}
